﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace Magic
{
    /// <summary>
    /// Логика взаимодействия для WindowT.xaml
    /// </summary>
    public partial class WindowT : Window
    {
        public WindowT()
        {
            InitializeComponent();
            DataSet dataset = new DataSet();
            dataset.ReadXml(@"D:\2ISIP-18 Vasiliev\Magic-master/file.xml");
            Datexml.ItemsSource = dataset.Tables[0].DefaultView;
        }

        private void ex_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void ClU_Click(object sender, RoutedEventArgs e)
        {
            Date date = new Date();
            Date.FName = User.Text;
            Date.LName = Use.Text;
            Date.Gp = Grp.Text;

            string name = User.Text + Use.Text;
            string box = User.Text + Use.Text + Grp.Text;

            if (box.Length < 4)
            {
                User.ToolTip = "Имя коротко";
                User.Background = Brushes.Red;
                Use.ToolTip = "Фамилия коротка";
                Use.Background = Brushes.Red;
                Grp.ToolTip = "Выберите группу";
                Grp.Background = Brushes.Red;
                MessageBox.Show("Неправильные данные");
            }
            else
            {
                User.ToolTip = "";
                User.Background = Brushes.Transparent;
                Use.ToolTip = "";
                Use.Background = Brushes.Transparent;
                Grp.ToolTip = "";
                Grp.Background = Brushes.Transparent;
                Test ts = new Test(name);
                ts.Show();
                this.Close();
            }
        }
    }
}
