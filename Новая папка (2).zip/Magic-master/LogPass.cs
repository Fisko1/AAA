﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magic
{
    class LogPass
    {
        public string logus = "admin";
        public string passus = "12345";
        public string login = "user";
        public string parol = "67890";

        public string LogU()
        {
            return logus;
        }

        public string PassU()
        {
            return passus;
        }

        public string Log()
        {
            return login;
        }

        public string Pas()
        {
            return parol;
        }
    }
}
