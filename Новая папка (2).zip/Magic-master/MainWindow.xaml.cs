﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Data;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Magic
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataSet dataset = new DataSet();
            dataset.ReadXml(@"D:\2ISIP-18 Vasiliev\Magic-master/file.xml");
            table.ItemsSource = dataset.Tables[0].DefaultView;
        }


        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            Date date = new Date();
            Date.FName = Name.Text;
            Date.LName = LasName.Text;
            Date.Gp = Groups.Text;

            string name = Name.Text + LasName.Text;
            string box = Name.Text + LasName.Text + Groups.Text;
            
            if (box.Length < 4)
            {
                Name.ToolTip = "Имя коротко";
                Name.Background = Brushes.Red;
                LasName.ToolTip = "Фамилия коротка";
                LasName.Background = Brushes.Red;
                Groups.ToolTip = "Выберите группу";
                Groups.Background = Brushes.Red;
                MessageBox.Show ("Неправильные данные");
            }
            else
            {
                Name.ToolTip = "";
                Name.Background = Brushes.Transparent;
                LasName.ToolTip = "";
                LasName.Background = Brushes.Transparent;
                Groups.ToolTip = "";
                Groups.Background = Brushes.Transparent;
                new Test(name).Show();
                this.Close();
            }
        }

        private void imag_Click(object sender, RoutedEventArgs e)
        {
              
            this.Background = new ImageBrush(new BitmapImage(new Uri(@"https://www.trueachievements.com/customimages/095426.jpg")));
        }

        private void ex_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
