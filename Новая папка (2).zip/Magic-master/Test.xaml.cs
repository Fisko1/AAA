﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Navigation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Magic
{
    /// <summary>
    /// Логика взаимодействия для Test.xaml
    /// </summary>
    public partial class Test : Window
    {
        public Test(string name)
        {
            InitializeComponent();
            LB.Content += name;
        }


        private void End_Click(object sender, RoutedEventArgs e)
        {
            Date date = new Date();
            Date.anw = ver1.Name + ver2.Name + ver3.Name;
            
            StreamWriter d = new StreamWriter(Date.FName + Date.LName + ".csv", true, Encoding.Default);
            d.WriteLine("Имя:;Фамилия:;Группа:;Ответ:;",  Date.FName[0], Date.LName[1], Date.Gp[2], Date.anw[3]) ;
            d.WriteLine();


            if ((bool)ver1.IsChecked)
            {
                
                d.WriteLine("Безумный Шляпник");

                MessageBox.Show(Date.anw[3] + "Тест пройден");
                Menu win = new Menu();
                win.Show();
                this.Close();
            }
            else if ((bool)ver2.IsChecked)
            {
                
                d.WriteLine("Кофеман");

                MessageBox.Show("Тест пройден");
                Menu win = new Menu();
                win.Show();
                this.Close();
            }
            else if ((bool)ver3.IsChecked)
            {
                
                d.WriteLine("Зожник");

                MessageBox.Show("Тест пройден");
                Menu win = new Menu();
                win.Show();
                this.Close();
            }
            d.Close();
        }
    }
}
