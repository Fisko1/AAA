﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Magic
{
    /// <summary>
    /// Логика взаимодействия для Test.xaml
    /// </summary>
    public partial class Test : Page
    {
        public Test()
        {
            InitializeComponent();
        }

        private void StackPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if ((bool)ver1.IsChecked)
            {
                ver2.Content = "Новичок";
                ver3.Content = "Любитель";
                ver4.Content = "Профи";
            }
        }

        private void ver1_MouseMove(object sender, MouseEventArgs e)
        {
            if ((bool)ver1.IsChecked)
            {
                ver1.Content = "Да вы знаток";
            }
        }

        private void ver2_MouseMove(object sender, MouseEventArgs e)
        {
            if ((bool)ver2.IsChecked)
            {
                ver2.Content = "Любитель наград";
            }
        }

        private void ver3_MouseMove(object sender, MouseEventArgs e)
        {
            if((bool)ver3.IsChecked)
            {
                ver3.Content = "Философ";
            }
        }

        private void ver4_MouseMove(object sender, MouseEventArgs e)
        {
            if((bool)ver4.IsChecked)
            {
                ver4.Content = "Искатель";
            }
        }

        private void End_Click(object sender, RoutedEventArgs e)
        {
            Date date = new Date();
            StreamWriter s = new StreamWriter(Date.FName + Date.LName + ".csv", true, Encoding.Default);
            s.WriteLine("Имя: ;" + Date.FName);
            s.WriteLine("Фамилия: ;" + Date.LName);
            s.WriteLine("Группа: ;" + Date.Group);
            if ((bool)ver1.IsChecked)
            {
                s.WriteLine("Ответ: ; Друзь");
            }
            else if ((bool)ver2.IsChecked)
            {
                s.WriteLine("Ответ: ; Хрустальная сова");
            }
            else if ((bool)ver3.IsChecked)
            {
                s.WriteLine("Ответ: ; Смысл жизни");
            }
            else if ((bool)ver4.IsChecked)
            {
                s.WriteLine("Ответ: ; Вчерашний день");
            }
            s.Close();
        }
    }
}
