﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Test1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Отзывы.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Список.";

            return View();
        }

        public ActionResult Site()
        {
            ViewBag.Message = "Библиотека";

            return View();
        }
    }
}